﻿using NUnit.Framework;
using NaviriaAPI.DTOs.User;
using System.ComponentModel.DataAnnotations;
using NaviriaAPI.Entities.EmbeddedEntities;

namespace NaviriaAPI.Tests.DTOs.User
{
    [TestFixture]
    public class UserCreateDtoTests
    {
        // Positive Test Cases
        [Test]
        public void TC001_UserCreateDto_WithValidData_ShouldBeValid()
        {
            // Arrange
            var dto = new UserCreateDto
            {
                FullName = "Anna Kozlova",
                Nickname = "Anna2025",
                Gender = "f",
                BirthDate = new DateTime(2002, 5, 15),
                Email = "anna.kozlova@example.com",
                Password = "Secure123",
                FutureMessage = "Keep pushing!",
                
            };

            // Act
            var context = new ValidationContext(dto, serviceProvider: null, items: null);
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(dto, context, results, validateAllProperties: true);

            // Assert
            Assert.That(isValid, Is.True);
            Assert.That(results, Is.Empty);
        }


        // Negative Test Cases for FullName
        [Test]
        public void TC002_InvalidFullName_ShouldBeInvalid_WhenTooShort()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "Jo",
                Nickname = "john123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "Passw0rd123"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
            Assert.That(validationResults.Any(r => r.ErrorMessage.Contains("FullName must be at least 3 characters long.")), Is.True);
        }

        [Test]
        public void TC003_InvalidFullName_ShouldBeInvalid_WhenContainsInvalidCharacters()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John @ Doe",
                Nickname = "john123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "Passw0rd123"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
            Assert.That(validationResults.Any(r => r.ErrorMessage.Contains("FullName can only contain Cyrillic and Latin letters, spaces, apostrophes, and hyphens.")), Is.True);
        }

        // Negative Test Cases for Nickname
        [Test]
        public void TC004_InvalidNickname_ShouldBeInvalid_WhenTooShort()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John Doe",
                Nickname = "ab",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Password = "Passw0rd123"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
            Assert.That(validationResults.Any(r => r.ErrorMessage.Contains("Nickname must be at least 3 characters long.")), Is.True);
        }

        // Negative Test Cases for Nickname
        [Test]
        public void TC005_InvalidNickname_ShouldBeInvalid_WhenTooLong()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John Doe",
                Nickname = new string('A', 21),
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Password = "Passw0rd123"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
            
        }


        [Test]
        public void TC006_InvalidNickname_ShouldBeInvalid_WhenContainsInvalidCharacters()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John Doe",
                Nickname = "john@123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "Passw0rd123"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
            Assert.That(validationResults.Any(r => r.ErrorMessage.Contains("Nickname can only contain Latin letters and digits.")), Is.True);
        }

        // Negative Test Cases for Gender
        [Test]
        public void TC007_InvalidGender_ShouldBeInvalid_WhenNotMOrF()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John Doe",
                Nickname = "john123",
                Gender = "x", // Invalid gender
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "Passw0rd123"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
            Assert.That(validationResults.Any(r => r.ErrorMessage.Contains("Gender must be 'f' or 'm'.")), Is.True);
        }

        // Negative Test Cases for Password
        [Test]
        public void TC008_InvalidPassword_ShouldBeInvalid_WhenTooShort()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John Doe",
                Nickname = "john123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "Pass1" 
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
             
        }

        [Test]
        public void TC009_InvalidPassword_ShouldBeInvalid_WhenMissingUppercase()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John Doe",
                Nickname = "john123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "password123" // Missing uppercase letter
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
            Assert.That(validationResults.Any(r => r.ErrorMessage.Contains("Password must contain at least one uppercase letter, one lowercase letter, and one digit")), Is.True);
        }

        // Negative Test Cases for Email
        [Test]
        public void TC0010_InvalidEmail_ShouldBeInvalid_WhenIncorrectFormat()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = "John Doe",
                Nickname = "john123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "invalid@email", 
                Password = "Passw0rd123"

            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
        }

        [Test]
        public void TC011_InvalidEmail_ShouldBeInvalid_WhenMissingAtSymbol()
        {
            var dto = new UserCreateDto
            {
                FullName = "Jane Doe",
                Nickname = "jane123",
                Gender = "f",
                BirthDate = new DateTime(1995, 5, 20),
                Email = "jane.doeexample.com", // no '@'
                Password = "StrongPass1"
            };
            var results = new List<ValidationResult>();
            var context = new ValidationContext(dto);
            var isValid = Validator.TryValidateObject(dto, context, results, true);
            Assert.That(isValid, Is.False);
            Assert.That(results.Any(r => r.ErrorMessage.Contains("Email")), Is.True);
        }


        [Test]
        public void TC012_ValidFullName_ShouldBeValid_WhenMaxLength()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = new string('A', 50), 
                Nickname = "john123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "Passw0rd123",
                FutureMessage = "Future message"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.True);
        }

        [Test]
        public void TC013_InvalidFullName_ShouldBeInvalid_WhenExceedsMaxLength()
        {
            // Arrange
            var userDto = new UserCreateDto
            {
                FullName = new string('A', 51), 
                Nickname = "john123",
                Gender = "m",
                BirthDate = new DateTime(1990, 1, 1),
                Email = "john.doe@example.com",
                Password = "Passw0rd123"
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, validationContext, validationResults, true);

            // Assert
            Assert.That(isValid, Is.False);
        }

      
        [Test]
        public void TC014_UserCreateDto_ShouldBeValid_WithEmptyOptionalFields()
        {
            var userDto = new UserCreateDto
            {
                FullName = "Jane Smith",
                Nickname = "JaneS",
                Gender = "f",
                BirthDate = new DateTime(1995, 6, 20),
                Email = "jane.smith@example.com",
                Password = "ValidPass123",
                FutureMessage = "",
             
               
            };

            var results = new List<ValidationResult>();
            var context = new ValidationContext(userDto);
            var isValid = Validator.TryValidateObject(userDto, context, results, true);

            Assert.That(isValid, Is.True);
            Assert.That(results, Is.Empty);
        }

        [Test]
        public void TC015_InvalidFutureMessage_ShouldBeInvalid_WhenTooLong()
        {
            var dto = new UserCreateDto
            {
                FullName = "Oleg Vasylenko",
                Nickname = "olegv",
                Gender = "m",
                BirthDate = new DateTime(1988, 11, 23),
                Email = "oleg.v@example.com",
                Password = "Password1",
                FutureMessage = new string('a', 151)
            };
            var results = new List<ValidationResult>();
            var context = new ValidationContext(dto);
            var isValid = Validator.TryValidateObject(dto, context, results, true);
            Assert.That(isValid, Is.False);
        }

        [Test]
        public void TC016_InvalidFutureMessage_ShouldBeInvalid_WhenContainsInvalidCharacters()
        {
            var dto = new UserCreateDto
            {
                FullName = "Dmytro P.",
                Nickname = "dmytro777",
                Gender = "m",
                BirthDate = new DateTime(2000, 7, 17),
                Email = "d.p@example.com",
                Password = "Passw0rd!",
                FutureMessage = "Stay strong! #hope" // #
            };
            var results = new List<ValidationResult>();
            var context = new ValidationContext(dto);
            var isValid = Validator.TryValidateObject(dto, context, results, true);
            Assert.That(isValid, Is.False);
            Assert.That(results.Any(r => r.ErrorMessage.Contains("FutureMessage contains invalid characters.")), Is.True);
        }


    }
}
