﻿using MongoDB.Driver;
using NaviriaAPI.Data;
using NaviriaAPI.Entities;
using NaviriaAPI.IRepositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NaviriaAPI.Options;
using NaviriaAPI.Repositories;
using Moq;
using MongoDB.Bson;
using NaviriaAPI.Tests.helper;

namespace NaviriaAPI.Tests.Repositories
{
   
    [TestFixture]
    public class AssistantChatRepositoryTests : RepositoryTestBase<AssistantChatMessageEntity>
    {
        private IAssistantChatRepository _assistantChatRepository = null!;
        private string _testUserId = null!;

        public override void SetUp()
        {
            base.SetUp();
            _assistantChatRepository = new AssistantChatRepository(DbContext);
            _testUserId = ObjectId.GenerateNewId().ToString();
        }

    
        protected override IMongoCollection<AssistantChatMessageEntity> GetCollection(IMongoDbContext dbContext)
        {
            return dbContext.AssistantChatMessages;
        }


        [Test]
        public async Task TC001_AddMessageAsync_ShouldAddMessage()
        {
            var message = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = ObjectId.GenerateNewId().ToString(),
                Content = "Hello, this is a test message",
                CreatedAt = DateTime.UtcNow
            };

            // Додаємо повідомлення
            await _assistantChatRepository.AddMessageAsync(message);

            // Перевіряємо, чи повідомлення є в колекції
            var fetchedMessage = await _assistantChatRepository.GetByUserIdAsync(message.UserId);

            Assert.That(fetchedMessage.Count(), Is.EqualTo(1));
            Assert.That(fetchedMessage.First().Content, Is.EqualTo("Hello, this is a test message"));
        }


        [Test]
        public async Task TC002_GetByUserIdAsync_ShouldReturnMessagesForUser()
        {
            var message1 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "First message",
                CreatedAt = DateTime.UtcNow.AddMinutes(-10)
            };
            var message2 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "Second message",
                CreatedAt = DateTime.UtcNow
            };

            await _assistantChatRepository.AddMessageAsync(message1);
            await _assistantChatRepository.AddMessageAsync(message2);

            // Отримуємо всі повідомлення для користувача
            var messages = await _assistantChatRepository.GetByUserIdAsync(_testUserId);

            Assert.That(messages.Count(), Is.EqualTo(2));
            Assert.That(messages.First().Content, Is.EqualTo("First message"));
            Assert.That(messages.Last().Content, Is.EqualTo("Second message"));
        }

        [Test]
        public async Task TC003_DeleteAllForUserAsync_ShouldRemoveAllMessagesForUser()
        {
            var message1 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "Message 1",
                CreatedAt = DateTime.UtcNow.AddMinutes(-10)
            };
            var message2 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "Message 2",
                CreatedAt = DateTime.UtcNow
            };

            await _assistantChatRepository.AddMessageAsync(message1);
            await _assistantChatRepository.AddMessageAsync(message2);

            // Видаляємо всі повідомлення для користувача
            await _assistantChatRepository.DeleteAllForUserAsync(_testUserId);

            // Перевіряємо, що повідомлень для цього користувача більше не залишилось
            var messages = await _assistantChatRepository.GetByUserIdAsync(_testUserId);

            Assert.That(messages.Count(), Is.EqualTo(0));
        }

        [Test]
        public async Task TC004_CountByUserIdAsync_ShouldReturnCorrectMessageCount()
        {
            var message1 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "Message 1",
                CreatedAt = DateTime.UtcNow.AddMinutes(-10)
            };
            var message2 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "Message 2",
                CreatedAt = DateTime.UtcNow
            };

            await _assistantChatRepository.AddMessageAsync(message1);
            await _assistantChatRepository.AddMessageAsync(message2);

            // Перевіряємо кількість повідомлень для цього користувача
            var messageCount = await _assistantChatRepository.CountByUserIdAsync(_testUserId);

            Assert.That(messageCount, Is.EqualTo(2));
        }

        [Test]
        public async Task TC005_CountByUserIdAsync_ShouldReturnZeroWhenNoMessages()
        {
            // Перевіряємо кількість повідомлень для користувача без повідомлень
            var messageCount = await _assistantChatRepository.CountByUserIdAsync(_testUserId);

            Assert.That(messageCount, Is.EqualTo(0));
        }


        [Test]
        public async Task TC006_DeleteAllForUserAsync_ShouldNotThrowWhenNoMessagesExist()
        {
            // Calling delete for a user with no messages
            await _assistantChatRepository.DeleteAllForUserAsync(_testUserId);

            // Ensure it completes without errors
            Assert.Pass();
        }

        [Test]
        public async Task TC007_DeleteManyByUserIdAsync_ShouldDeleteSpecificMessages()
        {
            var message1 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "Message 1",
                CreatedAt = DateTime.UtcNow.AddMinutes(-10)
            };
            var message2 = new AssistantChatMessageEntity
            {
                Id = ObjectId.GenerateNewId().ToString(),
                UserId = _testUserId,
                Content = "Message 2",
                CreatedAt = DateTime.UtcNow
            };

            await _assistantChatRepository.AddMessageAsync(message1);
            await _assistantChatRepository.AddMessageAsync(message2);

            // Delete a single message
            await _assistantChatRepository.DeleteManyByUserIdAsync(_testUserId);

            // Verify that all messages for this user are deleted
            var messages = await _assistantChatRepository.GetByUserIdAsync(_testUserId);
            Assert.That(messages.Count(), Is.EqualTo(0));
        }

        [Test]
        public async Task TC008_DeleteAllForUserAsync_ShouldNotFailWhenNoMessagesExist()
        {
            await _assistantChatRepository.DeleteAllForUserAsync(_testUserId);

            // Ensure the method completes successfully without throwing errors
            Assert.Pass();
        }

        [Test]
        public async Task TC009_CountByUserIdAsync_ShouldReturnZeroForNoMessages()
        {
            var messageCount = await _assistantChatRepository.CountByUserIdAsync(ObjectId.GenerateNewId().ToString());


            Assert.That(messageCount, Is.EqualTo(0));
        }

       
    }
}
